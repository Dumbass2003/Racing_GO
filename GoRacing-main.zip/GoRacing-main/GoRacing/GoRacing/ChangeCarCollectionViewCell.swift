//
//  ChangeCarCollectionViewCell.swift
//  GoRacing
//
//  
//

import UIKit

class ChangeCarCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var carPicture: UIImageView!

    
}
